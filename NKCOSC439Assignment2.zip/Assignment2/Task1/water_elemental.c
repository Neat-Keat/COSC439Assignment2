#include <stdio.h>
int main(){
    printf("Transformation complete! You are now the Water Elemental!\n");
    return 0;
}