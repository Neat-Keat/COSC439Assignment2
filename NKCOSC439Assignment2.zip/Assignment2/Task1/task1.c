#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(){
    printf("Welcome to the Enchanted Fork and Exec Journey!\n");
    printf("Choose an element to transform into:\n");
    printf("1. Fire\n2. Water\n3. Earth\n4. Air\n");

    //print parent pid
    //printf("parent PID: %d\n", (int)getpid());

    int choice;
    scanf("%d", &choice);
    printf("you chose: %d", choice);

    //switch-case or if-else
        //fork
        //print child pid
        //load desired element's code

        pid_t pid;
        int status;

        pid = fork();

        if (pid == -1){
            perror("fork");
            exit(EXIT_FAILURE);
        } else if (pid == 0){
            //child process

            char *program;
            
            if (choice == 1){
                program = "./fire_elemental";
            } else if (choice == 2){
                program = "./water_elemental";
            } else if (choice == 3){
                program = "./earth_elemental";
            } else if (choice == 4){
                program = "./air_elemental";
            } 
            
            char *args[] ={program, NULL};
            execv(program, args);

            perror("execv error"); //execv only returns if an error occurs
            exit(EXIT_FAILURE);

        } else {
            //Parent process
            waitpid(pid, &status, 0);
            printf("Child process exited with status %d\n", WEXITSTATUS(status));
        }
        
        return 0;
}