#include <stdio.h>
int main(){
    printf("Transformation complete! You are now the Air Elemental!\n");
    return 0;
}