Nathan Ketterlinus
COSC439 Assignment 2
Professor Sajid
2/28/25

This archive contains all of my code for Assignment 2, and this document will walk the reader through running it! This guide assumes basic terminal knowledge in both Windows and Linux

-----------------------------------------
PREREQUISITES:
Linux:
	- gcc
	- make

How to Compile and Run code for each task:
-----------------------------------------
Task1 - Linux
	1. Open a terminal and navigate to the Task1 directory
	2. run "make"
	3. run "./task1"
	4. Enter a number 1-4 corresponding with the element you want to transform to!

-----------------------------------------
Task2 - Linux
	1. Open a terminal and navigate to the Task2 Directory
	2. run "make"
	2. run "./task2"

-----------------------------------------
Task3 - Windows
	1. Open a terminal and navigate to the Task3 Directory
	2. Open a second terminal and navigate to the Task3 Directory
	3. On the first terminal, run "writer.exe"
		a. this may need to be "./writer" if windows doesn't trust this code by default
	4. On the second terminal, run "reader.exe"
		a. this may need to be "./reader" if windows doesn't trust this code by default
