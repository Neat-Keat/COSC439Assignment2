#include <windows.h>
#include <stdio.h>

int main() {
    HANDLE hPipe;
    DWORD dwRead;
    char buffer[1024];

    // Connect to the named pipe
    hPipe = CreateFile(
        TEXT("\\\\.\\pipe\\MyPipe"), // Pipe name
        GENERIC_READ,                // Read access
        0,                           // No sharing
        NULL,                        // Default security attributes
        OPEN_EXISTING,               // Open the existing pipe
        0,                           // Default attributes
        NULL);                       // No template file

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("CreateFile failed, error %d\n", GetLastError());
        return 1;
    }

    // Read the data from the pipe
    if (!ReadFile(hPipe, buffer, sizeof(buffer), &dwRead, NULL)) {
        printf("ReadFile failed, error %d\n", GetLastError());
        return 1;
    }

    printf("Message received from the pipe: %s\n", buffer);

    // Close the pipe
    CloseHandle(hPipe);
    return 0;
}
