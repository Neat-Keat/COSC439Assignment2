#include <windows.h>
#include <stdio.h>

int main() {
    HANDLE hPipe;
    DWORD dwWritten;

    // Create a named pipe
    hPipe = CreateNamedPipe(
        TEXT("\\\\.\\pipe\\MyPipe"), // Pipe name
        PIPE_ACCESS_OUTBOUND,         // Write-only access
        PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
        1,                             // Number of instances
        1024,                          // Output buffer size
        1024,                          // Input buffer size
        0,                             // Default timeout
        NULL);                         // Default security attributes

    if (hPipe == INVALID_HANDLE_VALUE) {
        printf("CreateNamedPipe failed, error %d\n", GetLastError());
        return 1;
    }

    // Wait for the reader to connect
    printf("Waiting for the reader to connect...\n");
    if (!ConnectNamedPipe(hPipe, NULL)) {
        printf("ConnectNamedPipe failed, error %d\n", GetLastError());
        return 1;
    }

    // Write data to the pipe
    const char *message = "Hello from the writer!";
    if (!WriteFile(hPipe, message, (DWORD)strlen(message) + 1, &dwWritten, NULL)) {
        printf("WriteFile failed, error %d\n", GetLastError());
        return 1;
    }

    printf("Message written to the pipe: %s\n", message);

    // Close the pipe
    CloseHandle(hPipe);
    return 0;
}
