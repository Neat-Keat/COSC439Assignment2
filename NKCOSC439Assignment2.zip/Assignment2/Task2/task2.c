/*
Task: Write a captivating C program named task2.c that breathes life into this mystical tale.
The program must follow these steps: 
    1. Create five Factorions (threads), each assigned to compute the factorial of a specific number from an array named "arr”. 
    2. The arr consists of numbers [1, 2, 3, 4, 5]. 
    3. Simultaneously, the Parent, who conjured these Factorions, desires to perform a magical operation on the result returned by each Factorion. 
        The operation involves calculating the summation of the squares of the factorial results. The Parent should execute this operation and display the final result

Additional Guidelines: 
    ● Ensure that each Factorion independently computes the factorial of its designated number and stores the value using the ThreadParam struct. 
    ● Utilize a global variable “result” to store the result and display it as output.

*/

#include <stdio.h>
#include<pthread.h>

#define NUM_FACTORS 5 //Number of threads to be created
int arr[NUM_FACTORS] = {1,2,3,4,5}; //Array containing the numbers for which factorial will be cauculated
int result = 0; //global variable to store the final result (sum of squares of factorials)

typedef struct {
    int num; //Number for which factorial is to be calculated
    int factorial; //factorial of the number
} ThreadParams;

void *factorion(void *arg) {
    ThreadParams *params = (ThreadParams *)arg;
    
    //print the thread id
    //Calculate factorial and print
    int num = params->num;
    params->factorial = 1;

    for (int i = 1; i <= num; i++){
        params->factorial *= i;
    }

    printf("Thread ID: %lu, Factorial of %d: %d\n", pthread_self(), num, params->factorial);

    pthread_exit(NULL);
}

int main(){
    pthread_t threads [NUM_FACTORS];
    ThreadParams params[NUM_FACTORS];

    //create threads
    for (int i = 0; i < NUM_FACTORS; i++){
        params[i].num = arr[i];
        pthread_create(&threads[i], NULL, factorion, (void *)&params[i]); //explain
    }

    //wait for all threads to finish
    for (int i = 0; i < NUM_FACTORS; i++){
        pthread_join(threads[i], NULL);
    }

    //final the square of factorial here and add it to global variable result [hint: it should be inside the loop]
    for (int i = 0; i < NUM_FACTORS; i++){
        result += params[i].factorial * params[i].factorial;
    }

    //print the final result outside of the loop
    printf("Final Result: %d\n", result);

    return 0;
}